package com.example.sanhouronline

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
